﻿docker部署Robot

//下载镜像
docker pull sersms/sers_dotnet_gateway:2.0.1

---------------------------------
1.配置文件
  (x.1)把本文件所在目录中所有文件 拷贝 到宿主机的目录 /root/sers/Gateway
  (x.2)修改配置文件 appsettings.json
 

2.创建容器并运行
//（容器名称为sers_gateway，可自定义）
//  (--restart=always 自动重启)
//（--net=host 网络直接使用宿主机网络）（-p 6022:6022 端口映射）
//  (-v /etc/localtime:/etc/localtime)挂载宿主机localtime文件解决容器时间与主机时区不一致的问题

docker run --name=sers_gateway --restart=always --net=host -d -v /etc/localtime:/etc/localtime -v /root/sers/Gateway/appsettings.json:/root/app/Gateway/appsettings.json -v /root/sers/Gateway/Logs:/root/app/Gateway/Logs  -v /root/sers/Gateway/Data:/root/app/Gateway/Data sersms/sers_dotnet_gateway:2.0.1
 

3.应用已经运行
   可在文件夹/root/sers/Gateway/Logs 中查看日志



-------------------
//常用命令

//查看容器logs
docker logs sers_gateway

//停止容器
docker stop sers_gateway

//打开容器
docker start sers_gateway

//重启容器
docker restart sers_gateway


//删除容器
docker rm sers_gateway



﻿docker部署Gover

//下载镜像
docker pull sersms/sers_dotnet_gover:2.0.1

---------------------------------
1.配置文件
  (x.1)把本文件所在目录中所有文件 拷贝 到宿主机的目录 /root/sers/Gover
  (x.2)修改配置文件 appsettings.json

2.创建容器并运行
//（容器名称为sers_gover，可自定义）
//  (--restart=always 自动重启)
//（--net=host 网络直接使用宿主机网络）（-p 6022:6022 端口映射）
//  (-v /etc/localtime:/etc/localtime)挂载宿主机localtime文件解决容器时间与主机时区不一致的问题

docker run --name=sers_gover --restart=always --net=host -d -v /etc/localtime:/etc/localtime -v /root/sers/Gover/appsettings.json:/root/app/Gover/appsettings.json -v /root/sers/Gover/Logs:/root/app/Gover/Logs    sersms/sers_dotnet_gover:2.0.1
 

3.应用已经运行
   可在文件夹/root/sers/Gover/Logs 中查看日志

-------------------
//常用命令

//查看容器logs
docker logs sers_gover

//停止容器
docker stop sers_gover

//打开容器
docker start sers_gover

//重启容器
docker restart sers_gover


//删除容器
docker rm sers_gover



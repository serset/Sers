﻿docker部署Robot

//下载镜像
docker pull sersms.com:17005/sers/dotnet/robot:v2.0.1

---------------------------------
1.配置文件
  (x.1)把本文件所在目录中所有文件 拷贝 到宿主机的目录 /root/sers/Robot
  (x.2)修改配置文件 appsettings.json
 

2.创建容器并运行
//（容器名称为sers_robot，可自定义）
//  (--restart=always 自动重启)
//（--net=host 网络直接使用宿主机网络）（-p 6022:6022 端口映射）
//  (-v /etc/localtime:/etc/localtime)挂载宿主机localtime文件解决容器时间与主机时区不一致的问题

docker run --name=sers_robot --restart=always --net=host -d -v /etc/localtime:/etc/localtime -v /root/sers/Robot/appsettings.json:/root/app/Robot/appsettings.json -v /root/sers/Robot/Logs:/root/app/Robot/Logs  -v /root/sers/Robot/Data:/root/app/Robot/Data sersms.com:17005/sers/dotnet/robot:v2.0.1
 

3.应用已经运行
   可在文件夹/root/sers/Robot/Logs 中查看日志



-------------------
//常用命令

//查看容器logs
docker logs sers_robot

//停止容器
docker stop sers_robot

//打开容器
docker start sers_robot

//重启容器
docker restart sers_robot


//删除容器
docker rm sers_robot



﻿docker部署dotnet-SersAll


//下载镜像
docker pull sersms/sers_dotnet:2.1

---------------------------------

1.打开工作文件夹 /root/sers/dotnet_sersall，把部署文件拷贝进去（本文件夹）


2.创建容器并运行
//（容器名称为dotnet_sersall，可自定义）
//  (--restart=always 自动重启)
//（--net=host 网络直接使用宿主机网络）（-p 6022:6022 端口映射）
//  (-v /etc/localtime:/etc/localtime)挂载宿主机localtime文件解决容器时间与主机时区不一致的问题

docker run --name=dotnet_sersall  --net=host -d -v /etc/localtime:/etc/localtime -v /root/sers/dotnet_sersall:/root/app sersms/sers_dotnet:2.1

//自动启动
docker run --name=dotnet_sersall --restart=always --net=host -d -v /etc/localtime:/etc/localtime -v /root/sers/dotnet_sersall:/root/app sersms/sers_dotnet:2.1

3.应用已经运行
  http://ip:6022/index.html



-------------------
//常用命令

//查看容器logs
docker logs dotnet_sersall

//停止容器
docker stop dotnet_sersall

//打开容器
docker start dotnet_sersall

//重启容器
docker restart dotnet_sersall


//删除容器
docker rm dotnet_sersall



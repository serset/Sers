
# run on back
echo "start ServiceCenter.bash"
chmod 777 /root/app/ServiceCenter.bash
sh /root/app/ServiceCenter.bash > /root/app/ServiceCenter/Logs/ServiceCenter.log &


# run on back
echo "start Gateway.bash"
chmod 777 /root/app/Gateway.bash
sh /root/app/Gateway.bash > /root/app/Gateway/Logs/Gateway.log &


# run on front
echo "start Gover.bash"
chmod 777 /root/app/Gover.bash
sh /root/app/Gover.bash > /root/app/Gover/Logs/Gover.log 
 






# Contributing to skywalking-netcore

One of the easiest ways to contribute is to participate in discussions and discuss issues. You can also contribute by submitting pull requests with code changes.

## General feedback and discussions?
Please start a discussion on the [issue tracker](https://github.com/OpenSkywalking/skywalking-netcore/issues).
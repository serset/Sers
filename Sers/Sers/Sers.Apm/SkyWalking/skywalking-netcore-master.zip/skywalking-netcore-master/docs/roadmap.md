# Roadmap

## v0.8.0
- TraceContext refactoring.
- Upgrade to Skywalking 6.0 protocol.
- Fix known bugs in the issue list.
- CLR runtime monitoring.
- Support IIS monitoring and tracing.
- ASP.NET and WCF request tracing.

## v0.9.0
- CLR Profiler(Experimental feature)
- Support plug-in.
- More third-party library support, such as mysql, redis, kafka, rabbitmq..

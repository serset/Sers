﻿namespace SkyWalking.Sample.Backend.Models
{
    public class Application
    {
        public int Id { get; set; }
        
        public string Name { get; set; }
    }
}
namespace SkyWalking
{
    public interface IEnvironmentProvider
    {
        string EnvironmentName { get; }
    }
}
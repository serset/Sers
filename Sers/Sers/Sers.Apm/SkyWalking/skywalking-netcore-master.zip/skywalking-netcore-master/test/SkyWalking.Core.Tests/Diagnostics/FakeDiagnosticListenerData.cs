﻿using System;

namespace SkyWalking.Core.Tests.Diagnostics
{
    public class FakeDiagnosticListenerData
    {
        public string Name { get; set; }
        
        public DateTime Timestamp { get; set; }
    }
}
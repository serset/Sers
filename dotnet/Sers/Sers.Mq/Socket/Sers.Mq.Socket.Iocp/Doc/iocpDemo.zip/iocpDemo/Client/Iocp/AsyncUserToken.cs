﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using Sers.Core.Extensions;

namespace Sers.Mq.SocketMq.Iocp
{
    public class AsyncUserToken
    {

        public void Stop()
        {
            try
            {
                socket?.Shutdown(SocketShutdown.Both);
            }
            catch (Exception) { }           
        }
        public void Init(Socket socket)
        {
            this.socket = socket;
            connectTime = DateTime.Now;  
        }

        /// <summary>
        /// 客户端IP地址
        /// </summary>
        private IPAddress IPAddress => ((IPEndPoint)(socket.RemoteEndPoint)).Address;

        /// <summary>
        /// 远程地址
        /// </summary>
        private EndPoint remote => socket.RemoteEndPoint;

        /// <summary>
        /// 通信SOKET
        /// </summary>
        public Socket socket { get;private set; }

        /// <summary>
        /// 连接时间
        /// </summary>
        private DateTime connectTime { get; set; }




        #region buffer

        

        private List<ArraySegment<byte>> buffer  = new List<ArraySegment<byte>>();

        int buffLen = 0;

        int frameLen = -1;

        public void AppendData(byte[] data)
        {
            lock (buffer)
            {
                buffer.Add(new ArraySegment<byte>(data));
                buffLen += data.Length;
            }
        }
        public List<ArraySegment<byte>> GetMessageFrame()
        {
            lock (buffer)
            {
                if (frameLen < 0)
                {
                    if (buffLen < 4) return null;

                    frameLen = buffer.ByteDataPopInt32();
                    buffLen -= 4;
                }

                if (frameLen > buffLen)
                {
                    return null;
                }

                if (frameLen == buffLen)
                {
                    frameLen = -1;
                    buffLen = 0;

                    var frame = buffer;
                    buffer = new List<ArraySegment<byte>>();
                    return frame;
                }

                buffLen -= frameLen;
                return buffer.ByteDataPopByteData(frameLen);
            }          
        }



        #endregion




        public void SendMessage(List<ArraySegment<byte>> data)
        {
            if (socket == null || !socket.Connected)
                return;

            Int32 len = data.ByteDataCount();

            data.Insert(0, len.Int32ToArraySegmentByte());

            socket.SendAsync(data, SocketFlags.None); 
        }


    }
}

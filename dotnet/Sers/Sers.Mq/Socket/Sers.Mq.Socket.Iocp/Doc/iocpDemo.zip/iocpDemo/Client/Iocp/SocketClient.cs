﻿// https://freshflower.iteye.com/blog/2285286

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Sers.Core.Module.Log;

namespace Sers.Mq.SocketMq.Iocp
{
    public class SocketClient
    {
        #region public 


        /// <summary>
        /// 缓存区大小
        /// </summary>
        public int receiveBufferSize = 10240;


        /// <summary>
        /// 当前连接状态
        /// </summary>
        //public bool Connected { get { return socket != null && socket.Connected; } }


        public Action<List<ArraySegment<byte>>> OnReceiveMessage;

        public Action Conn_OnDisconnected;




        // Create an uninitialized client instance.
        // To start the send/receive processing call the
        // Connect method followed by SendReceive method.
        public SocketClient(string ip = "127.0.0.1", int port = 10345)
        {
            // Instantiates the endpoint and socket.
            hostEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
            socket = new Socket(hostEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            userToken.Init(socket);

            receiveEventArgs.Completed += new EventHandler<SocketAsyncEventArgs>(IO_Completed);
            receiveEventArgs.SetBuffer(new byte[receiveBufferSize], 0, receiveBufferSize);

        }

        /// <summary>
        /// 连接到主机
        /// </summary>
        /// <returns>0.连接成功, 其他值失败,参考SocketError的值列表</returns>
        public bool Connect()
        {
            SocketAsyncEventArgs connectArgs = new SocketAsyncEventArgs();

            connectArgs.RemoteEndPoint = hostEndPoint;
            connectArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnConnect);

            socket.ConnectAsync(connectArgs);
            autoConnectEvent.WaitOne(); //阻塞. 让程序在这里等待,直到连接响应后再返回连接结果
            return connectArgs.SocketError == SocketError.Success;
        }

        /// Disconnect from the host.
        public void Close()
        {
            autoConnectEvent.Close();
            if (socket.Connected)
            {
                socket.Close();
            }

            socket.Disconnect(false);
        }

        public void SendMessage(List<ArraySegment<byte>> data)=> userToken.SendMessage(data);
        #endregion




        // The socket used to send/receive messages.
        private Socket socket;

        // Flag for connected socket.
        private Boolean connected = false;

        // Listener endpoint.
        private IPEndPoint hostEndPoint;


 
        private SocketAsyncEventArgs receiveEventArgs = new SocketAsyncEventArgs();

        private AsyncUserToken userToken = new AsyncUserToken();



        // Signals a connection.
        private AutoResetEvent autoConnectEvent = new AutoResetEvent(false);
      

        // Calback for connect operation
        private void OnConnect(object sender, SocketAsyncEventArgs e)
        {
            // Signals the end of connection.
            autoConnectEvent.Set(); //释放阻塞.

   

            // Set the flag for socket connected.
            connected = (e.SocketError == SocketError.Success);
            //如果连接成功,则初始化socketAsyncEventArgs
            if (connected)
            {               
                //启动接收,不管有没有,一定得启动.否则有数据来了也不知道.
                if (!e.ConnectSocket.ReceiveAsync(receiveEventArgs))
                    ProcessReceive(receiveEventArgs);
            }


        }

        #region args

        void IO_Completed(object sender, SocketAsyncEventArgs e)
        { 
            // determine which type of operation just completed and call the associated handler
            switch (e.LastOperation)
            {
                case SocketAsyncOperation.Receive:
                    ProcessReceive(e);
                    break;
                default:
                    throw new ArgumentException("The last operation completed on the socket was not a receive or send");
            }
        }

        // This method is invoked when an asynchronous receive operation completes. 
        // If the remote host closed the connection, then the socket is closed.  
        // If data was received then the data is echoed back to the client.
        //
        private void ProcessReceive(SocketAsyncEventArgs e)
        {
            try
            {
                // check if the remote host closed the connection
 
                if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
                {
                    //读取数据
                    byte[] data = new byte[e.BytesTransferred];
                    Array.Copy(e.Buffer, e.Offset, data, 0, e.BytesTransferred);
                    userToken.AppendData(data);

                    List<ArraySegment<byte>> msgFrame;
                    while ((msgFrame = userToken.GetMessageFrame()) != null)
                    {
                        try
                        {
                            OnReceiveMessage?.Invoke(msgFrame);
                        }
                        catch (Exception ex)
                        {
                            Logger.Error(ex);
                        }                        
                    }

                    if (!socket.ReceiveAsync(e))
                        ProcessReceive(e);
                }
                else
                {
                    ProcessError(e);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }
 

        #endregion

        #region read write

        // Close socket in case of failure and throws
        // a SockeException according to the SocketError.
        private void ProcessError(SocketAsyncEventArgs e)
        {
           
            if (socket.Connected)
            {
                // close the socket associated with the client
                try
                {
                    socket.Shutdown(SocketShutdown.Both);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                }
                finally
                {
                    if (socket.Connected)
                    {
                        socket.Close();
                    }
                    connected = false;
                }
            }

            Conn_OnDisconnected?.Invoke();
        }

       

        

        #endregion

 

    }
}

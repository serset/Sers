﻿//  https://freshflower.iteye.com/blog/2285272 


using Sers.Core.Module.Log;
using Sers.Core.Util.Pool;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Sers.Mq.SocketMq.Iocp
{
    class SocketServer
    {

        #region public 

        /// <summary>
        /// 缓存区大小
        /// </summary>
        public int receiveBufferSize = 10240;


        #region 事件


        public Action<AsyncUserToken> Conn_OnDisconnected;
        public Action<AsyncUserToken> Conn_OnConnected;

        /// <summary>
        /// 接收到客户端的数据事件          public delegate void OnReceiveData(AsyncUserToken token, List<ArraySegment<byte>> messageFrame);
        /// </summary>
        public Action<AsyncUserToken, List<ArraySegment<byte>>> OnReceiveMessage;
        #endregion


        /// <summary>
        ///  
        /// </summary>
        /// <param name="numConnections">最大连接数</param>
        /// <param name="receiveBufferSize"></param>
        public SocketServer(int maxConnectCount = 200)
        {
            this.maxConnectCount = maxConnectCount;

            m_maxNumberAcceptedClients = new Semaphore(maxConnectCount, maxConnectCount);

            ioEventPool.Capacity = maxConnectCount;
        }



        #region Start Stop

        public bool Start(int port = 10345)
        {
            return Start(new IPEndPoint(IPAddress.Any, port));
        }

        /// <summary>
        /// 启动服务
        /// </summary>
        /// <param name="localEndPoint"></param>
        public bool Start(IPEndPoint localEndPoint)
        {
            try
            {
                m_clients.Clear();
                listenSocket = new Socket(localEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                listenSocket.Bind(localEndPoint);
                // start the server with a listen backlog of 100 connections
                listenSocket.Listen(maxConnectCount);
                // post accepts on the listening socket
                StartAccept(null);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return false;
        }

        /// <summary>
        /// 停止服务
        /// </summary>
        public void Stop()
        {
            foreach (AsyncUserToken token in m_clients)
            {
                try
                {
                    token.Stop();
                    Conn_OnDisconnected?.Invoke(token);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                }
            }
            try
            {
                listenSocket.Shutdown(SocketShutdown.Both);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            listenSocket.Close();
            int c_count = m_clients.Count;
            lock (m_clients) { m_clients.Clear(); }
        }


        #endregion

        #endregion


        /// <summary>
        /// 最大连接数
        /// </summary>
        private int maxConnectCount;   


       
        Socket listenSocket;            //监听Socket
        
        int m_clientCount = 0;              //连接的客户端数量
        Semaphore m_maxNumberAcceptedClients;

        List<AsyncUserToken> m_clients= new List<AsyncUserToken>();//客户端列表

 


      
        

        SocketAsyncEventArgs SocketAsyncEventArgs_Create()
        {
            var readWriteEventArg = ioEventPool.PopOrNull();

            if (readWriteEventArg != null) return readWriteEventArg;

            readWriteEventArg = new SocketAsyncEventArgs();
            readWriteEventArg.Completed += new EventHandler<SocketAsyncEventArgs>(IO_Completed);
            readWriteEventArg.UserToken = new AsyncUserToken();

            readWriteEventArg.SetBuffer(new byte[receiveBufferSize],0, receiveBufferSize);

            return readWriteEventArg;
        }

        ObjectPool<SocketAsyncEventArgs> ioEventPool = new ObjectPool<SocketAsyncEventArgs>() ;

        void SocketAsyncEventArgs_Release(SocketAsyncEventArgs ea)
        {
            ioEventPool.Push(ea);
        }

       


        // Begins an operation to accept a connection request from the client 
        //
        // <param name="acceptEventArg">The context object to use when issuing 
        // the accept operation on the server's listening socket</param>
        private void StartAccept(SocketAsyncEventArgs acceptEventArg)
        {
            if (acceptEventArg == null)
            {
                acceptEventArg = new SocketAsyncEventArgs();
                acceptEventArg.Completed += new EventHandler<SocketAsyncEventArgs>(AcceptEventArg_Completed);
            }
            else
            {
                // socket must be cleared since the context object is being reused
                acceptEventArg.AcceptSocket = null;
            }

            m_maxNumberAcceptedClients.WaitOne();
            if (!listenSocket.AcceptAsync(acceptEventArg))
            {
                ProcessAccept(acceptEventArg);
            }
        }

        // This method is the callback method associated with Socket.AcceptAsync 
        // operations and is invoked when an accept operation is complete
        //
        private void AcceptEventArg_Completed(object sender, SocketAsyncEventArgs e)
        {
            ProcessAccept(e);
        }

        private void ProcessAccept(SocketAsyncEventArgs e)
        {
            try
            {
                Interlocked.Increment(ref m_clientCount);
                // Get the socket for the accepted client connection and put it into the 
                //ReadEventArg object user token
                SocketAsyncEventArgs readEventArgs = SocketAsyncEventArgs_Create();
                AsyncUserToken userToken = (AsyncUserToken)readEventArgs.UserToken;

                userToken.Init(e.AcceptSocket); 

                lock (m_clients) { m_clients.Add(userToken); }


                Conn_OnConnected?.Invoke( userToken);

                if (!e.AcceptSocket.ReceiveAsync(readEventArgs))
                {
                    ProcessReceive(readEventArgs);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            // Accept the next connection request
            if (e.SocketError == SocketError.OperationAborted) return;
            StartAccept(e);
        }


        void IO_Completed(object sender, SocketAsyncEventArgs e)
        {
            // determine which type of operation just completed and call the associated handler
            switch (e.LastOperation)
            {
                case SocketAsyncOperation.Receive:
                    ProcessReceive(e);
                    break;
                case SocketAsyncOperation.Send:
                    ProcessSend(e);
                    break;
                default:
                    throw new ArgumentException("The last operation completed on the socket was not a receive or send");
            }

        }


        // This method is invoked when an asynchronous receive operation completes. 
        // If the remote host closed the connection, then the socket is closed.  
        // If data was received then the data is echoed back to the client.
        //
        private void ProcessReceive(SocketAsyncEventArgs e)
        {
            try
            {
                // check if the remote host closed the connection
                AsyncUserToken token = (AsyncUserToken)e.UserToken;
                if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
                {
                    //读取数据
                    //TODO 可不copy 而直接使用吗？
                    byte[] data = new byte[e.BytesTransferred];
                    Array.Copy(e.Buffer, e.Offset, data, 0, e.BytesTransferred);
                    token.AppendData(data);

                    List<ArraySegment<byte>> msgFrame;
                    while ((msgFrame = token.GetMessageFrame()) != null)
                    {
                        OnReceiveMessage?.Invoke(token, msgFrame);
                    }                

                    //继续接收. 为什么要这么写,请看Socket.ReceiveAsync方法的说明
                    if (!token.socket.ReceiveAsync(e))
                        ProcessReceive(e);
                }
                else
                {
                    CloseClientSocket(e);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }

        // This method is invoked when an asynchronous send operation completes.  
        // The method issues another receive on the socket to read any additional 
        // data sent from the client
        //
        // <param name="e"></param>
        private void ProcessSend(SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {
                // done echoing data back to the client
                AsyncUserToken token = (AsyncUserToken)e.UserToken;
                // read the next block of data send from the client
                bool willRaiseEvent = token.socket.ReceiveAsync(e);
                if (!willRaiseEvent)
                {
                    ProcessReceive(e);
                }
            }
            else
            {
                CloseClientSocket(e);
            }
        }

        //关闭客户端
        private void CloseClientSocket(SocketAsyncEventArgs e)
        {
            AsyncUserToken token = e.UserToken as AsyncUserToken;

            lock (m_clients) { m_clients.Remove(token); }
            //如果有事件,则调用事件,发送客户端数量变化通知

            Conn_OnDisconnected?.Invoke(token);
            // close the socket associated with the client
            try
            {
                token.socket.Shutdown(SocketShutdown.Send);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            token.socket.Close();
            // decrement the counter keeping track of the total number of clients connected to the server
            Interlocked.Decrement(ref m_clientCount);
            m_maxNumberAcceptedClients.Release();
            // Free the SocketAsyncEventArg so they can be reused by another client
            e.UserToken = new AsyncUserToken();

            SocketAsyncEventArgs_Release(e);      
        }



    }
}

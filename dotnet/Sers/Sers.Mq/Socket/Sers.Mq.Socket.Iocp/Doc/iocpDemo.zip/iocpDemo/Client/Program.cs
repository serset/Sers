﻿using Sers.Core.Util.Common;
using System;
using System.Threading;
using Sers.Core.Extensions;
using System.Text;
using Sers.Mq.SocketMq.Iocp;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");


            //创建连接对象, 连接到服务器
            var smanager = new SocketClient();

            if (smanager.Connect())
            {
                //连接成功后,就注册事件. 最好在成功后再注册.
                smanager.OnReceiveMessage = (data) =>
                {
                    Console.WriteLine("get :" + data?.ByteDataToString());
                };
                smanager.Conn_OnDisconnected = () =>
                {
                    Console.WriteLine("ServerStopEvent ServerStopEvent");
                };
            }
            else
            {
                Console.WriteLine("无法连接");
                Console.ReadLine();
                return;
            }
            

           

            while (true)
            {
                String msg = CommonHelp.NewGuid();
                byte[] buff = Encoding.UTF8.GetBytes(msg);

                Console.WriteLine("Send:" + msg);
                smanager.SendMessage(buff.BytesToByteData());

                Thread.Sleep(500);
            }




        }
    }
}

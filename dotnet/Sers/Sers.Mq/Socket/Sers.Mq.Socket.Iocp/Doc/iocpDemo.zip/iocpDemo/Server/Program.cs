﻿using Sers.Mq.SocketMq.Iocp;
using System;
using System.Threading;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            SocketServer m_socket = new SocketServer(2);

            m_socket.OnReceiveMessage = (token,msg) => 
            {
                token.SendMessage(msg);
            };

 
            m_socket.Start();

            Console.WriteLine("Hello World!");

            while (true)
            {
                //Request.Send("dddd");
                Thread.Sleep(1000);
            }

        }
    }
}
